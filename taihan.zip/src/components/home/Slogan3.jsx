import React from "react";

export default () => (
  <svg
    id="slogan3"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100.744 100.752"
  >
    <g data-name="Group 9" transform="translate(-936.5 -2090.5)">
      <g id="Group_8" data-name="Group 8" transform="translate(937 2091)">
        <g id="Layer_5_copy" transform="translate(25.398 17.077)">
          <path
            id="Path_34"
            data-name="Path 34"
            className="cls-11"
            d="M32.5,56.843,61.275,21.26,56.223,49.871H76.8l-28.78,36.98,6.627-28.788H31.62Z"
            transform="translate(-31.62 -21.26)"
          />
        </g>
        <g id="Layer_6_copy" transform="translate(0 0)">
          <path
            id="Path_35"
            data-name="Path 35"
            className="cls-11"
            d="M102.115,16.475l-2.932-8.1L94.01,13.543Z"
            transform="translate(-18.499 -1.647)"
          />
          <path
            id="Path_36"
            data-name="Path 36"
            className="cls-11"
            d="M4.38,85.36l.731,8.594,6.345-3.663Z"
            transform="translate(-0.862 -16.797)"
          />
          <g id="Group_7" data-name="Group 7">
            <path
              id="Path_37"
              data-name="Path 37"
              className="cls-22"
              d="M3.052,64.571A49.042,49.042,0,0,1,78.435,10.008V9.093h.1A49.865,49.865,0,0,0,2.209,64.571Z"
              transform="translate(0 0)"
            />
            <path
              id="Path_38"
              data-name="Path 38"
              className="cls-22"
              d="M88.92,20.98c-.193.185-.386.361-.586.546A49.516,49.516,0,0,1,98.92,41.053a57.7,57.7,0,0,1,1.735,12.956A49.06,49.06,0,0,1,9.674,79.5H8.75A49.852,49.852,0,1,0,88.92,20.98Z"
              transform="translate(-1.722 -4.128)"
            />
          </g>
        </g>
      </g>
    </g>
  </svg>
);
