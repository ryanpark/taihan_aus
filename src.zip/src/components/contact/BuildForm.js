//<script type="text/javascript" defer src="//www.123formbuilder.com/embed/4485387.js" data-role="form" data-default-width="650px"></script>
function insertScript(url) {
  const scriptEl = document.createElement("script");
  scriptEl.src = url;
  scriptEl.defer = true;
  scriptEl.setAttribute("data-role", "form");
  scriptEl.setAttribute("data-default-width", "650px");
  document.head.appendChild(scriptEl);
  console.log("done");
}

export default insertScript;
