import React, { Fragment } from "react";
import styled from "styled-components";
import MediaQuery from "react-responsive";

import { screen } from "../../global/constant";
import CloseButtonSVG from "../../global/CloseButton";

const List = styled.div`
  position: relative;
  cursor: pointer;
  display: inline-flex;
  @media ${screen.lgDown} {
    display: block;
  }

  img {
    width: 100%;
    height: auto;
    display: block;
  }

  @media ${screen.mdUp} {
    img {
      width: auto;
    }
  }
`;

const Paragraph = styled.p`
  position: absolute;
  bottom: 20px;
  left: 20px;
  line-height: 26px;
`;

const Description = styled.p`
  line-height: 26px;
`;

const Ghost = styled.div`
  width: 640px;
  height: 528px;
`;

const Title = styled.p`
  text-decoration: underline;
  line-height: 26px;
  margin-bottom: 15px;
`;

export default class Project extends React.Component {
  state = { showMore: false };

  showMore() {
    this.setState({ showMore: !this.state.showMore });
    this.props.updateShowState();
  }

  render() {
    const isShowing = !this.props.isHiding || this.state.showMore;

    const SelectedContent = styled.div`
      margin: 20px;

      span {
        text-decoration: none !important;
      }

      @media ${screen.mdUp} {
        margin-top: 0px;
        margin-bottom: 0px;
        margin-right: ${props =>
          this.props.direction === "right" ? null : "15px"};
        margin-left: ${props =>
          this.props.direction === "right" ? "15px" : null};
      }
    `;

    const CloseButton = styled.div`
      text-align: right;
      margin-right: 40px;

      svg {
        width: 40px;
        fill: white;
      }

      @media ${screen.mdUp} {
        margin: 0px;
        position: absolute;
        left: ${props => (this.props.direction === "right" ? null : "18px")};
        right: ${props => (this.props.direction === "left" ? null : "0px")};
        top: ${props => (this.props.direction === "left" ? "-51px" : "0px")};
      }
    `;

    const content = () => (
      <SelectedContent>
        <Title>{this.props.title} </Title>
        <Description>{this.props.description} </Description>
      </SelectedContent>
    );
    return isShowing ? (
      <List onClick={this.showMore.bind(this)}>
        {!this.state.showMore && (
          <Fragment>
            <Paragraph>{this.props.title}</Paragraph>
            <img alt="" src={this.props.imgSrc} />
          </Fragment>
        )}

        {this.state.showMore && (
          <Fragment>
            <MediaQuery query={screen.xlgUp}>
              <CloseButton>
                <CloseButtonSVG />
              </CloseButton>
            </MediaQuery>
            <MediaQuery query={screen.xlgUp}>
              {this.props.direction === "left" && content()}
            </MediaQuery>
            <img alt="" src={this.props.selectedSrc} />
            <MediaQuery query={screen.xlgUp}>
              {this.props.direction === "right" && content()}
            </MediaQuery>
            <MediaQuery query={screen.lgDown}>
              {content()}
              <CloseButton>
                <CloseButtonSVG />
              </CloseButton>
            </MediaQuery>
          </Fragment>
        )}
      </List>
    ) : (
      this.props.index !== 1 && <Ghost />
    );
  }
}
