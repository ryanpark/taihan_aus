import React from "react";
import styled from "styled-components";
import XLargeBg from "../../components/home/heroLarge.jpg";
import LargeBg from "../../components/home/hero.jpg";
import redArrows from "../../components/home/redArrows.png";

import superImg from "../../components/home/superpower.jpg";
import { color, screen } from "../../global/constant";

const Img = styled.div`
  background-image: url(${XLargeBg});
  background-color: ${color.blue};
  background-repeat: no-repeat;
  background-position: 50% 50%;
  height: 697px;
  position: relative;
  margin-top: -87px;
`;

const Wrapper = styled.div`
  max-width: 1280px;
  margin: 0 auto;
  background-image: url(${redArrows});
  background-repeat: no-repeat;
  background-position: 16px 127px;
`;

const Super = styled.div`
  width: 514px;
  height: 415px;
  background-image: url(${superImg});
  top: 400px;
  position: absolute;
  right: 1px;
  margin-right: 20px;

  @media ${screen.xlgUp} {
    right: 186px;
    margin-right: 0px;
  }
`;
const HeadingWrapper = styled.div`
  padding-left: 23px;
  padding-top: 177px;
  position: relative;
`;

const PrimaryHeading = styled.h1`
  color: white;
  font-size: 50px;
  line-height: 68px;
  font-weight: lighter;
  margin-bottom: 20px;
`;
const SecondaryHeading = styled.h1`
  color: white;
  font-size: 32px;
  line-height: 39px;
  font-weight: lighter;
`;

export default () => (
  <Img>
    <Wrapper>
      <HeadingWrapper>
        <PrimaryHeading>
          The Power Lighting Up <br />
          The World, Taihan.
        </PrimaryHeading>
        <SecondaryHeading>
          Taihan, the global cable & solution
          <br /> company is lighting up the world
        </SecondaryHeading>
        <Super />
      </HeadingWrapper>
    </Wrapper>
  </Img>
);
