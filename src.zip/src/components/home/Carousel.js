import React, { Fragment } from "react";
import styled from "styled-components";
import { color } from "../../global/constant";

import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import img1 from "./clients1.png";
import img2 from "./clients2.png";
import img3 from "./clients3.png";
import img4 from "./clients4.png";

const Title = styled.h2`
  font-size: 26px;
  text-align: center;
  color: ${color.blue};
`;

const Wrapper = styled.div`
  padding: 0px 0 150px 0;
`;

export default () => (
  <Fragment>
    <Wrapper className="projects">
      <Title>Our Clients</Title>
      <Carousel showThumbs={false} showStatus={false} showIndicators={false}>
        <div>
          <img alt="clients" src={img1} />
        </div>
        <div>
          <img alt="clients" src={img2} />
        </div>
        <div>
          <img alt="clients" src={img3} />
        </div>
        <div>
          <img alt="clients" src={img4} />
        </div>
      </Carousel>
    </Wrapper>
  </Fragment>
);
