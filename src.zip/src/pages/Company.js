import React from "react";
import styled from "styled-components";
import bg from "../components/company/bgcompany.png";
import person from "../components/company/person.png";
import building from "../components/company/building.png";
import logo from "../components/company/taihan CI_basic.jpg";

import { color, screen } from "../global/constant";
const Container = styled.div`
  max-width: 1280px;
  margin: 0 auto;
`;
const Hero = styled.div`
  background: url(${bg});
  background-repeat: no-repeat;
  background-color: ${color.blue};
  position: relative;
  padding: 95px 30px 30px 30px;

  @media ${screen.mdUp} {
    padding: 150px;
  }
`;

const SuperMan = styled.img`
  display: block;
  width: 100%;
  height: auto;

  @media ${screen.mdUp} {
    position: absolute;
    bottom: -171px;
    margin: 0px;
    width: auto;
    height: auto;
  }
`;
const Heading = styled.h1`
  text-align: center;
  font-size: 30px;
  line-height: 41px;
  margin-bottom: 40px;
  font-weight: lighter;

  @media ${screen.mdUp} {
    font-size: 45px;
    line-height: 55px;
  }
`;

const Paragraph = styled.p`
  line-height: 24px;
  text-align: center;
  margin-bottom: 20px;
`;

const Wrapper = styled.div`
  background: white;
  color: ${color.blue};
  padding: 20px 20px;

  @media ${screen.mdUp} {
    padding: 250px 0;
  }
`;

const Competitiveness = styled.div`
  padding: 20px;

  @media ${screen.mdUp} {
    display: flex;
    justify-content: space-between;
    padding: 154px;
  }
`;

const Lists = styled.ul`
  li {
    margin-bottom: 25px;
  }
`;

const Bold = styled.div`
  font-weight: bold;
  margin-bottom: 25px;
`;

const Office = styled.div`
  padding: 20px;
  text-align: center;

  @media ${screen.mdUp} {
    padding: 20px 154px;
  }
`;

const ListsWrapper = styled.div`
  padding: 40px 0;
`;

const Img = styled.img`
  width: 100%;
  height: auto;
`;

const Download = styled.div`
  margin: 120px 0px;
  img {
    display: block;
    margin: 0 auto;
    padding-bottom: 20px;
  }
  a {
    text-decoraion: underline;
    color: ${color.blue};
    span {
      text-decoration: underline;
    }
  }
`;

export default class Company extends React.Component {
  componentDidMount() {
    const { props } = this;
    props.updateMobileMenuState();
    this.props.updatePageLocation("Company");
  }
  render() {
    return (
      <Container>
        <Hero>
          <Heading>
            Taihan will open a new era to be the one with <br />
            100 year history
          </Heading>
          <Paragraph>
            We are preparing for the future, towards being known as a great
            company with a hundred years of history, <br /> based on the
            capability and energy which have made us grow and win over
            customers’ trust over the last 60 years. <br /> We will keep
            developing while communicating with our global customers, with a
            strong will for accomplishing <br /> our goal and responsibility for
            realizing the best customer satisfaction. Just like we have been
            doing so far, <br /> we promise to proceed resolutely despite
            hardships and ordeals. <br /> TAIHAN’s challenge and innovation
            towards a bigger world and a better tomorrow have just started.
          </Paragraph>
          <SuperMan alt="superman" src={person} />
        </Hero>
        <Wrapper>
          <Heading>Global Leading Company</Heading>
          <Paragraph>
            We are approaching our half-century milestone in core competences,
            accumulating 50 years of excellence.
          </Paragraph>
          <Paragraph>
            {" "}
            In 1955, when the national industrial development began, after
            Korean War, Taihan Electric Wire was established as the first wire
            and <br /> cable company in Korea. During half a century, our
            company has grown into a global company with high competitiveness
            <br />
            in power. communication and metal industry.
          </Paragraph>
          <Paragraph>
            Now, our company is standing shoulder to shoulder with the leading
            companies in the world not only in the power and communication cable{" "}
            <br />
            but also in the network field and stainless steel business through
            its steady improvement in technology and quality. Cable and metal
            industries <br /> are more meaningful in that every members of
            society share its value together. Taihan provides the quality
            products and services <br /> whenever and wherever customers need.{" "}
          </Paragraph>
          <Paragraph>
            We will also develop and further expand our involvement in growth
            industries such as home network, <br /> solar power generation,
            rental and leisure busines s.{" "}
          </Paragraph>
          <Paragraph>
            Taihan is committed to contribute to the value creation of our
            customers with the ceaseless change and innovation, and maximizes
            the <br /> Corporate value through its commitment. We will make
            every efforts to be a company growing with customers based <br /> on
            the right-of-way management.{" "}
          </Paragraph>
          <Paragraph>
            The creation of customer’s value is the first priority of all of
            Taihan family.{" "}
          </Paragraph>
          <Competitiveness>
            <div>
              <Img alt="building" src={building} />
            </div>
            <ListsWrapper>
              <Bold>Taihan’s Competitiveness</Bold>
              <Lists>
                <li>&#8226; &nbsp; Fully Equipped Manufacturing Facilities</li>
                <li>
                  &#8226; &nbsp; Experienced & Skilled Techincal Man Power
                </li>
                <li>&#8226; &nbsp; Turn-key Solution</li>
                <li>&#8226; &nbsp; Customer Oriented Sales & Management</li>
                <li>
                  &#8226; &nbsp; Various Facilities & Process for Quality
                  Assurance
                </li>
              </Lists>
            </ListsWrapper>
          </Competitiveness>
          <Office>
            <Download>
              <a
                href="http://www.taihan.com/images/kor/contents/ci/taihan_CI.zip"
                alt="taihan"
              >
                <img src={logo} alt="logo" />
                <span>Download Corporate Identity</span>
              </a>
            </Download>
            <Paragraph>
              <Bold>Taihan Electric Wire CO., LTD Head Office</Bold>{" "}
            </Paragraph>
            <Paragraph>
              G.sqaure Building No.1039, <br />
              Hogae-Dong, Anyang City,
              <br />
              Gyeonggi-Do, Korea
            </Paragraph>
          </Office>
        </Wrapper>
      </Container>
    );
  }
}
