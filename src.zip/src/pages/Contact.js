import React from "react";
import styled from "styled-components";
import { color, screen } from "../global/constant";
import Map from "../components/contact/map.png";
import BgCompany from "../components/contact/bgCompany.png";
import Iframe from "react-iframe";

const Container = styled.div`
  max-width: 1280px;
  margin: 0 auto;
  background: white;
`;

const Information = styled.div`
  background: ${color.blue};
  background-image: url("${BgCompany}");
  padding: 20px;

  @media ${screen.mdUp} {
    padding: 100px 50px 40px 50px;
    display: flex;
    justify-content: center;
  }
`;
const Paragraph = styled.p`
  line-height: 24px;
  margin-bottom: 20px;
`;

const Wrapper = styled.div`
  @media ${screen.mdUp} {
    margin-right: 200px;
  }
`;

const mapUrl = "https://goo.gl/maps/g4dW1jqXnyB2";

const MapLink = styled.a`
  display: block;
`;

const MapImg = styled.img`
  width: 100%;
  height: auto;
`;

const Bold = styled.span`
  font-size: 22px;
`;

const url = "//www.123formbuilder.com/embed/4485387.js";

export default class Contact extends React.Component {
  componentDidMount() {
    const { props } = this;
    props.updateMobileMenuState();
    props.updatePageLocation("Contact");
  }
  shouldComponentUpdate() {
    return false;
  }
  render() {
    return (
      <div>
        <Information>
          <Wrapper>
            <Paragraph>
              <Bold>Taihan Electric Australia Pty Ltd</Bold>
            </Paragraph>
            <Paragraph>
              Suite 704, 815 Pacific Highway,
              <br /> Chatswood NSW 2067 Australia
            </Paragraph>
            <Paragraph>
              T +61 (0)2 9411 7564 <br />
              F +61 (0)2 9411 7579 <br />
              M +61 (0) 0450 602 842 <br />
              E sales@taihan.com.au <br />
              &nbsp;&nbsp;&nbsp;c.kim@taihan.com.au
            </Paragraph>
          </Wrapper>
          <MapLink href={mapUrl} target="_blank">
            <MapImg src={Map} alt="map" />
          </MapLink>
        </Information>

        <Container>
          <Iframe
            url="//www.123formbuilder.com/my-contact-form-4485387.html"
            width="100%"
            height="800px"
            id="contactform123"
            allowTransparency
            className="myClassname"
            display="initial"
            position="relative"
            allowFullScreen
          />
        </Container>
      </div>
    );
  }
}
